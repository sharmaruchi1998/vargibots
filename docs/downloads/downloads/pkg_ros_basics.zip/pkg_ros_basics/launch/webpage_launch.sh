#!/bin/bash

# Store URL in a variable
URL1="https://www.e-yantra.org/"

# Print some message
echo "** Opening $URL1 in Firefox **"

# Use firefox to open the URL in a new window
firefox -new-window $URL1 